<?php
// Token de autenticación
$authToken = "eyJhbGciOiJSUzI1NiJ9.eyJqdGkiOiI1MDUyMmIwYS03ZjdlLTQxZjYtYjAyMS1lYTBhNjI2MmJlMDAiLCJzdWIiOiIxODIwOTE0IiwiaWRfc2Vzc2lvbiI6IjIwN2Y1MDE4LWJlZmMtMzE3OC05YWJiLTlkYWIwOGY3Zjk5YyIsImF1dGhvcml0aWVzIjpbIkVuZFVzZXJSb2xlIl0sImFwaXAiOiIxOTAuMTc4Ljc2LjI1MCIsImNsaWVudF9pZCI6InIwSGl3YWRydXFVSjlTVGFXbHBSZXNVRHJvRDRsUk81IiwiZXhwaXJlc19hdCI6MTcwMTQwMDkyMywiaWF0IjoxNzAxMzg2NTIzLCJleHAiOjE3MDE0MDA5MjMsImlkX3NzbyI6MTgyMDUwMywiaWRfZGV2aWNlIjoiODhkMjA1YmUtNGNiOC00YTc2LTljZGQtYTM4MjMzZTRmNGZkIn0.gLs4296M0mK7sY6BzT5fIa44-wLv-qU0raTXn0nFrE88dJMVE25igWJY2eowFN5gvxyj0zmTN61Uj0qUfwVMvcm-k98SE8Opo6f8zO-tiSr0K8c2RTY9_mfoBwj0FFC5pMtQwrrIPYPZbweYBxGgdHOV5lYKjjVpdJlerk19WuE6io6uSw1yOigJ0aPydndRXSrGqYQ7VreRJmwOgr43hzGeO0fOt8SD2Ole0hPebNEfQl8-PzY0nnVD53LS__KwbBOjepnWOVyZFkMP5pdJY1njy9yetetQqfrtoBTXv0smxD177Z2dlQLjtP3iSSrRfDIbvAdqFe4dB703ripPqg";

// URL para obtener el token
$url = "https://web-bev.telecentro.net.ar/proxy/channelStream";

// Configurar la solicitud cURL como POST
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, ''); // Campo de datos vacío, ya que no hay datos adicionales en tu ejemplo
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/x-www-form-urlencoded',
    'X-An-Webservice-Customerauthtoken: ' . $authToken
));

// Realizar la solicitud
$response = curl_exec($ch);

// Verificar si la solicitud fue exitosa
if ($response === false) {
    die('Error al realizar la solicitud cURL: ' . curl_error($ch));
}

// Decodificar la respuesta JSON
$data = json_decode($response, true);

// Imprimir la respuesta completa para depuración
echo "Respuesta completa: " . print_r($data, true) . PHP_EOL;

// Verificar si la estructura de la respuesta es la esperada
if (isset($data['result']['newAuthToken'])) {
    // Obtener el nuevo token
    $newToken = $data['result']['newAuthToken'];

    // Imprimir el nuevo token (puedes almacenarlo en un archivo, base de datos, etc.)
    echo "Nuevo Token: " . $newToken . PHP_EOL;

    // También puedes acceder a otros datos en la respuesta, como la URL del flujo de canales
    echo "URL del flujo de canales: " . $data['result']['url'] . PHP_EOL;
} else {
    // Manejar el caso en que la estructura de la respuesta no sea la esperada
    echo "Error: Estructura de respuesta inesperada.";
}

// Cerrar la conexión cURL
curl_close($ch);
?>
