<?php
header("Location: https://megatelevisiontv.live");
exit;
?>
