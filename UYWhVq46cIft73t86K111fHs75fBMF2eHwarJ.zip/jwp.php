<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="robots" content="noindex">
  <style>
    body {
      margin: 0;
      padding: 0;
      overflow: hidden;
    }

    #loading-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.8);
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    #loading-message {
      font-size: 36px;
      color: #fff;
      text-align: center;
      margin-bottom: 20px;
    }

    #loading-info {
      font-size: 24px;
      color: #fff;
      text-align: center;
    }

    #player {
      width: 100vw;
      height: 56.25vw;
    }
  </style>
  <script src="https://content.jwplatform.com/libraries/KB5zFt7A.js"></script>
  <script> jwplayer.key = 'XSuP4qMl+9tK17QNb+4+th2Pm9AWgMO/cYH8CI0HGGr7bdjo';</script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
  <div id="loading-overlay">
    <div id="loading-message">Cargando... Por favor, espere.</div>
    <div id="loading-info">El reproductor puede tardar hasta más de 1 minuto.</div>
  </div>
  <div id="player"></div>

  <script>
    function getParameterByName(name) {
      name = name.replace(/[\[]/, "\[").replace(/[\]]/, "\]");
      var regex = new RegExp("[\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
      return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    }

    var getURL = getParameterByName('get');
    var getKEY = getParameterByName('key');
    var getKEY2 = getParameterByName('key2');

    var channelUrl = 'https://sourcerussia--sopetov23.repl.co/' + getURL + '.php?get=' + getURL + '&key=' + getKEY + '&key2=' + getKEY2;

    $.getJSON(channelUrl, function(data) {
      var url = data.url;
      var playerInstance = jwplayer("player");

      $('#loading-overlay').show();

      playerInstance.setup({
        playlist: [{
          "title": "Mega Deportes TV",
          "description": "megadeportes.xyz",
          "image": "#",
          "sources": [{
            "default": false,
            "type": "dash",
            "file": url,
            "drm": {
              "clearkey": {
                "keyId": getKEY,
                "key": getKEY2
              }
            },
            "label": "0"
          }]
        }],
        width: "100%",
        height: "100%",
        aspectratio: "16:9",
        autostart: true,
        cast: {},
        sharing: {}
      });

      playerInstance.on('ready', function() {
        $('#loading-overlay').hide();
      });
    });
  </script>
</body>
</html>
