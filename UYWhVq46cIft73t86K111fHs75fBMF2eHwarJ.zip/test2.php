<?php

// Incluir el archivo token.php si existe
if (file_exists('token.php')) {
    include_once 'token.php';
} else {
    $token = null;
}

// Verificar si el token está cerca de expirar (por ejemplo, en los últimos 10 minutos)
$expiracionToken = 1 * 60; // 1 minuto en segundos
$tiempoActual = time();

function obtenerNuevoToken() {
    // Lógica para obtener un nuevo token
    $nuevoToken = solicitarNuevoToken();

    // Verificar si se obtuvo un token válido
    if ($nuevoToken !== null && esTokenValido($nuevoToken)) {
        // Si el nuevo token es válido, devolverlo
        return $nuevoToken;
    } else {
        // Si no se obtuvo un token válido, manejar el error o devolver un token de respaldo
        return "token_de_respaldo_aqui";
    }
}

function solicitarNuevoToken() {
    // Lógica específica para solicitar un nuevo token
    // Puedes llamar a tu servicio web o realizar cualquier otra acción necesaria
    // ...

    // Por ahora, solo devolvemos un token de ejemplo
    return "nuevo_token_aqui";
}

function esTokenValido($token) {
    // Lógica para verificar si un token es válido
    // Esto podría incluir la verificación de la firma, la expiración, etc.
    // ...

    // Por ahora, simplemente devolvemos true, pero debes implementar una lógica real aquí
    return true;
}

if (empty($token) || ($expiracionToken + $tiempoActual) > json_decode(base64_decode(explode('.', $token)[1]))->exp) {
    // Si el token está vacío o está a punto de expirar, obtener uno nuevo
    $token = obtenerNuevoToken();

    // Guardar el token en un archivo
    file_put_contents('token.php', '<?php $token = "' . $token . '";');
}


$ch = curl_init();

$headers = array(
    'Accept: application/json',
    'Accept-Language: es-MX,en-US;q=0.9',
    'Connection: keep-alive',
    'Content-Type: application/x-www-form-urlencoded',
    'Origin: https://www.telecentroplay.com.ar',
    'Referer: https://www.telecentroplay.com.ar/',
    'Sec-Fetch-Dest: empty',
    'Sec-Fetch-Mode: cors',
    'Sec-Fetch-Site: cross-site',
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
  'X-An-Webservice-CustomerAuthToken: ' . $token, // Ahora $token debería estar definido
    'X-An-Webservice-IdentityKey: r0HiwadruqUJ9STaWlpResUDroD4lRO5',
    'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
    'sec-ch-ua-mobile: ?0',
    'sec-ch-ua-platform: "Windows"'
);

$channels = array('152'); // Lista de valores para 'idChannel'

$results = array();

foreach ($channels as $channel) {
    $data = array(
        'idChannel' => $channel
    );

    curl_setopt($ch, CURLOPT_URL, 'https://web-bev.telecentro.net.ar/proxy/channelStream');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);

    if ($response !== false) {
        $json = json_decode($response, true);

        if (isset($json['result']['newAuthToken']) && isset($json['result']['url'])) {
            // Usar el nuevo token
            $token = $json['result']['newAuthToken'];

            // Guardar el token en un archivo
            file_put_contents('token.php', '<?php $token = "' . $token . '";');

            // Resto del código para procesar la URL, similar a tu código original
            $url = str_replace('http://', 'https://', $json['result']['url']);
            $url = str_replace(':80', '', $url);
            $results[] = array('url' => $url);
        } else {
            $results[] = array('error' => 'No se encontró la URL o el nuevo token en la respuesta');
        }
    } else {
        $results[] = array('error' => 'Error en la solicitud');
    }
}

curl_close($ch);

// Imprimir los resultados en lugar de guardar en un archivo JSON
echo json_encode($results[0]); // Usar $results[0] ya que solo hay un elemento en este ejemplo
?>
