<?php
$ch = curl_init();

$headers = array(
    'Accept: application/json',
    'Accept-Language: es-MX,en-US;q=0.9',
    'Connection: keep-alive',
    'Content-Type: application/x-www-form-urlencoded',
    'Origin: https://www.telecentroplay.com.ar',
    'Referer: https://www.telecentroplay.com.ar/',
    'Sec-Fetch-Dest: empty',
    'Sec-Fetch-Mode: cors',
    'Sec-Fetch-Site: cross-site',
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
    'X-An-Webservice-CustomerAuthToken: eyJhbGciOiJSUzI1NiJ9.eyJqdGkiOiJkNGVlN2Q3My1mZDdiLTRmMTQtODE2OC04MGFiZjAxYzhkNWUiLCJzdWIiOiIxNDIzNjE2IiwiaWRfc2Vzc2lvbiI6ImFmZWE3OTE0LTM3ODctMzFmYy1hZmUzLThkNGZjYjQ1YWQ1MSIsImF1dGhvcml0aWVzIjpbIkVuZFVzZXJSb2xlIl0sImFwaXAiOiIxOTEuODIuNjYuMiIsImNsaWVudF9pZCI6InIwSGl3YWRydXFVSjlTVGFXbHBSZXNVRHJvRDRsUk81IiwiZXhwaXJlc19hdCI6MTcwMDg4MDA5NiwiaWF0IjoxNzAwODY1Njk2LCJleHAiOjE3MDA4ODAwOTYsImlkX3NzbyI6MTQyMzQ3NSwiaWRfZGV2aWNlIjoiNTcyNjhjMWUtZjI3YS00N2IwLWJlMjctOGE5NTU2NTc2ZDY2In0.RaHPaG3t6oqvovRvIpcUNpmJGvXq0PZqq2v_I9shGToFRtXXImCEboG0_9zSj4FL2lyME3yqOLCtHDtveUe5clOEJMlSmhaXpEbFVuftLJy1XXlko1ERhOutc-EO3miBcgXInQblkVRQJTdpU5LbSSEUPdi9BRDBOQ2Ewne0spYlaVXhXc13yMWgkOx6SvtAmRkGLNJSQ1WBXmLLKa0jFZMmltJgaj9Jm_NoD92vIWTgyFNeswgGTV1Twz932WdFECj8YJVMMSdtk01WHjf357pq1eTCLN6xtOyBFjF1b3HUph4h00FAZfimnflSAzr5KIqs_ifCICm7tQ4jVkVhvA',
    'X-An-Webservice-IdentityKey: r0HiwadruqUJ9STaWlpResUDroD4lRO5',
    'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
    'sec-ch-ua-mobile: ?0',
    'sec-ch-ua-platform: "Windows"'
);

$channels = array('1191', '152', '140', '7', '64', '98', '1192', '4', '50'); // Lista de valores para 'idChannel'

$results = array();

foreach ($channels as $channel) {
    $data = array(
        'idChannel' => $channel
    );

    curl_setopt($ch, CURLOPT_URL, 'https://web-bev.telecentro.net.ar/proxy/channelStream');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);

    if ($response !== false) {
        $json = json_decode($response, true);
        $results[$channel] = $json;
    } else {
        $results[$channel] = 'Error en la solicitud';
    }
}

curl_close($ch);

header('Content-Type: application/json');
echo json_encode($results);
?>