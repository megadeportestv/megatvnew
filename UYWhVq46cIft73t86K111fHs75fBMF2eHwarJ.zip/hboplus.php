<?php

include 'token.php';

$ch = curl_init();

$headers = array(
    'Accept: application/json',
    'Accept-Language: es-MX,en-US;q=0.9',
    'Connection: keep-alive',
    'Content-Type: application/x-www-form-urlencoded',
    'Origin: https://www.telecentroplay.com.ar',
    'Referer: https://www.telecentroplay.com.ar/',
    'Sec-Fetch-Dest: empty',
    'Sec-Fetch-Mode: cors',
    'Sec-Fetch-Site: cross-site',
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
    'X-An-Webservice-CustomerAuthToken: ' . $token,
    'X-An-Webservice-IdentityKey: r0HiwadruqUJ9STaWlpResUDroD4lRO5',
    'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
    'sec-ch-ua-mobile: ?0',
    'sec-ch-ua-platform: "Windows"'
);

$channels = array('71'); // Lista de valores para 'idChannel'

$results = array();

foreach ($channels as $channel) {
    $data = array(
        'idChannel' => $channel
    );

    curl_setopt($ch, CURLOPT_URL, 'https://web-bev.telecentro.net.ar/proxy/channelStream');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);

    if ($response !== false) {
        $json = json_decode($response, true);

        if (isset($json['result']['url'])) {
            // Cambiar http:// a https:// y eliminar el puerto :80
            $url = str_replace('http://', 'https://', $json['result']['url']);
            $url = str_replace(':80', '', $url);
            $results[] = array('url' => $url);
        } else {
            $results[] = array('error' => 'No se encontró la URL en la respuesta');
        }
    } else {
        $results[] = array('error' => 'Error en la solicitud');
    }
}

curl_close($ch);

// Imprimir los resultados en lugar de guardar en un archivo JSON
echo json_encode($results[0]); // Usar $results[0] ya que solo hay un elemento en este ejemplo
?>
